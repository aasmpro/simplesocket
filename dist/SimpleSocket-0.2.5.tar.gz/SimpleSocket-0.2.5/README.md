# SimpleSocket
simple implementation of python socket for creating server/client based programs supporting threading.
