__title__ = 'SimpleSocket'
__version__ = '0.2.5'
__author__ = 'Abolfazl Amiri'
__author_email__ = 'aa.smpro@gmail.com'
__license__ = 'unlicensed'

VERSION = __version__
